<?php echo $_header; ?> 
<?php echo $_navbar; ?> 
<?php echo $_sidebar; ?> 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
   
<?php echo $_content; ?> 

</div>
<?php echo $_footer; ?> 
